// default package
// Generated Jul 8, 2012 1:31:08 AM by Hibernate Tools 3.4.0.CR1

import java.util.List;
import javax.naming.InitialContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Example;

/**
 * Home object for domain model class InstituteBranchUserAcademicProgram.
 * @see .InstituteBranchUserAcademicProgram
 * @author Hibernate Tools
 */
public class InstituteBranchUserAcademicProgramHome {

	private static final Log log = LogFactory
			.getLog(InstituteBranchUserAcademicProgramHome.class);

	private final SessionFactory sessionFactory = getSessionFactory();

	protected SessionFactory getSessionFactory() {
		try {
			return (SessionFactory) new InitialContext()
					.lookup("SessionFactory");
		} catch (Exception e) {
			log.error("Could not locate SessionFactory in JNDI", e);
			throw new IllegalStateException(
					"Could not locate SessionFactory in JNDI");
		}
	}

	public void persist(InstituteBranchUserAcademicProgram transientInstance) {
		log.debug("persisting InstituteBranchUserAcademicProgram instance");
		try {
			sessionFactory.getCurrentSession().persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void attachDirty(InstituteBranchUserAcademicProgram instance) {
		log.debug("attaching dirty InstituteBranchUserAcademicProgram instance");
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(InstituteBranchUserAcademicProgram instance) {
		log.debug("attaching clean InstituteBranchUserAcademicProgram instance");
		try {
			sessionFactory.getCurrentSession().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void delete(InstituteBranchUserAcademicProgram persistentInstance) {
		log.debug("deleting InstituteBranchUserAcademicProgram instance");
		try {
			sessionFactory.getCurrentSession().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public InstituteBranchUserAcademicProgram merge(
			InstituteBranchUserAcademicProgram detachedInstance) {
		log.debug("merging InstituteBranchUserAcademicProgram instance");
		try {
			InstituteBranchUserAcademicProgram result = (InstituteBranchUserAcademicProgram) sessionFactory
					.getCurrentSession().merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public InstituteBranchUserAcademicProgram findById(java.lang.Integer id) {
		log.debug("getting InstituteBranchUserAcademicProgram instance with id: "
				+ id);
		try {
			InstituteBranchUserAcademicProgram instance = (InstituteBranchUserAcademicProgram) sessionFactory
					.getCurrentSession().get(
							"InstituteBranchUserAcademicProgram", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(InstituteBranchUserAcademicProgram instance) {
		log.debug("finding InstituteBranchUserAcademicProgram instance by example");
		try {
			List results = sessionFactory.getCurrentSession()
					.createCriteria("InstituteBranchUserAcademicProgram")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}
}
